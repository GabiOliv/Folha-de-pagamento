<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 

<?php

$digitado = $_GET ['cpf'] ;

function ValidaCPF($cpf){
    
    if(empty($cpf)) {
		return false;
    }
    
        $cpf = preg_replace('/[^0-9]/', '', $cpf);
        
        if (strlen($cpf) != 11) {
            return false;
            }
        
        $digitoA = 0;
        $digitoB = 0;

        for($i =0, $x = 10; $i <= 8; $i++, $x--){
            $digitoA += $cpf[$i] * $x;
        }

        for($i =0, $x = 11; $i <= 9; $i++, $x--){
            
                if(str_repeat($i, 11) == $cpf){
                    return false;
            }
            $digitoB += $cpf[$i] * $x;
        }

        $somaA = (($digitoA%11) < 2 ) ? 0 : 11-($digitoA%11);
        $somaB = (($digitoB%11) < 2 ) ? 0 : 11-($digitoB%11);

        if($somaA != $cpf[9] || $somaB != $cpf[10]){
            return false;
        }
        else{
            return true;
        }
    }

    
if(ValidaCPF($digitado)){
    header("location:bat.php");
}
else{
header("location:cadastro2.php");
}
?>