<!doctype html>
<html>

<head>
<meta charset="utf-8">
<title>Exercício - SOMA </title>
<link href="enc/estilo.css" rel="stylesheet" type="text/css">
</head>
<body>
<h2>
      <font face="Verdana, Arial, Helvetica, sans-serif">Sistema de Conferência de Cálculo de Folha de Pagamento
      </font></h2> <hr align="center" color="#0099CC"><p>

</center>
<h7>

<form method="POST"action="emitir.php">
  <font face="Verdana, Arial, Helvetica, sans-serif"> <font size="2">Valor Hora:
  <input name="ValorHora" type="text" size="5" />
  <font color="#FF0000">(Use ponto ao invés da vírgula) </font><br>
  </font></font> <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
  <br>
  Mes de competência <br>
  <select name="Mes">
    <option value="Janeiro">Janeiro </option>
    <option value="Fevereiro">Fevereiro </option>
    <option value="Março">Março </option>
    <option value="Abril">Abril </option>
    <option value="Maio">Maio </option>
    <option value="Junho">Junho </option>
    <option value="Julho">Julho </option>
    <option value="Agosto">Agosto </option>
    <option value="Setembro">Setembro </option>
    <option value="Outubro">Outubro </option>
    <option value="Novembro">Novembro </option>
    <option value="Dezembro">Dezembro </option>
  </select>
  <br>
  <br>
  Nº de dias úteis <br>
  <input type="text" name="DiasUteis" size="3"/>
  <br>
  <br>
  Nº de domingos + Feriados <br>
  <input type="text" name="Domingos" size="3" />
  <br>
  <br>
  Nº de dias trabalhados<br>
  <input type="text" name="DiasTrab" />
  </font><font face="Verdana, Arial, Helvetica, sans-serif">
  <p>
  <hr align="center" size="1" noshade>
 <br>
  <hr align="center" size="1" noshade>
  <input type="submit" value="Calcular">
  </font> <font face="Arial, Helvetica, sans-serif"> </font>
</form>
</h7>
///


  </font> </div>
<div align="center">
<p align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">
<!-- 
<?php
$V1 = 7.33; // Este valor corresponde a 7hs e 20min de trabalho diário
$ValorHora = $_POST["ValorHora"];
$Mes = $_POST["Mes"];
$DiasUteis = $_POST["DiasUteis"];
$Domingos = $_POST["Domingos"];
$DiasTrab = $_POST["DiasTrab"];
//$Tipo = $_POST["Tipo"];

//// CÁLCULO HORISTA /////

$HorasTrab = $DiasTrab * $V1;
$VlrHr = $HorasTrab * $ValorHora;
$DSR = $Domingos * $V1;
$VlrDSR = $DSR * $ValorHora;

     $HorasTrab = $DiasTrab * $V1;
             $VlrHr = $HorasTrab * $ValorHora;
             $DSR = $Domingos * $V1;
             $VlrDSR = $DSR * $ValorHora;
             $SalarioH = $VlrDSR + $VlrHr;

                   echo "<center>O CALCULO COM BASE EM HORISTA FICA ASSIM</center><BR>";
                   echo "Mês selecionado para o cálculo = $Mes<br>";
                   echo "Cálculo das horas trabalhadas = $HorasTrab<br>";
                   echo "Valor Hora = $VlrHr<br>";
                   echo "Descanso Semanal Remunerado = $DSR<br>";
                   echo "Valor do DSR = $VlrDSR<br>";
             echo "Valor do Salário = $SalarioH <br><p>";

//// FIM DO CÁLCULO DO SALÁRIO HORISTA /////



//// CÁLCULO MENSALISTA /////

       $Salario = 220 * $ValorHora;
       echo "O CALCULO COM BASE EM MENSALISTA FICA ASSIM<br>";
       echo "Cálculo das horas trabalhadas = $Salario<br>";

//// FIM DO CÁLCULO DO SALÁRIO MENSALISTA /////



?>     -->
</body>
<style>
/* CSS reset */
*, *:before, *:after { 
  margin:0;
  padding:0;
  font-family: Arial,sans-serif;
}
 
/* remove a linha dos links */
a{
  text-decoration: none;
}
 
/* esconde as ancoras da tela */
a.links{
  display: none;
}


.content{
  width: 500px;
  min-height: 560px;    
  margin: 0px auto;
  position: relative;   
}


h1{
  font-size: 48px;
  color: #066a75;
  padding: 2px 0 10px 0;
  font-family: Arial,sans-serif;
  font-weight: bold;
  text-align: center;
  padding-bottom: 30px;
}


h1:after{
  content: ' ';
  display: block;
  width: 100%;
  height: 2px;
  margin-top: 10px;
  background: -webkit-linear-gradient(left, rgba(147,184,189,0) 0%,rgba(147,184,189,0.8) 20%,rgba(147,184,189,1) 53%,rgba(147,184,189,0.8) 79%,rgba(147,184,189,0) 100%); 
  background: linear-gradient(left, rgba(147,184,189,0) 0%,rgba(147,184,189,0.8) 20%,rgba(147,184,189,1) 53%,rgba(147,184,189,0.8) 79%,rgba(147,184,189,0) 100%); 
}


p{
  margin-bottom:15px;
}
 
.content p:first-child{
  margin: 0px;
}
 
label{
  color: #405c60;
  position: relative;
}


/* placeholder */
::-webkit-input-placeholder  {
  color: #bebcbc; 
  font-style: italic;
}
 
input:-moz-placeholder,
textarea:-moz-placeholder{
  color: #bebcbc;
  font-style: italic;
}


input {
  outline: none;
}
 
/*estilo dos input,  menos o checkbox */
input:not([type="checkbox"]){
  width: 95%;
  margin-top: 4px;
  padding: 10px;    
  border: 1px solid #b2b2b2;
 
  -webkit-border-radius: 3px;
  border-radius: 3px;
 
  -webkit-box-shadow: 0px 1px 4px 0px rgba(168, 168, 168, 0.6) inset;
  box-shadow: 0px 1px 4px 0px rgba(168, 168, 168, 0.6) inset;
 
  -webkit-transition: all 0.2s linear;
  transition: all 0.2s linear;
}
 
/*estilo do botão submit */
input[type="submit"]{
  width: 100%!important;
  cursor: pointer;  
  background: rgb(61, 157, 179);
  padding: 8px 5px;
  color: #fff;
  font-size: 20px;  
  border: 1px solid #fff;   
  margin-bottom: 10px;  
  text-shadow: 0 1px 1px #333;
 
  -webkit-border-radius: 5px;
  border-radius: 5px;
 
  transition: all 0.2s linear;
}
 
/*estilo do botão submit no hover */
input[type="submit"]:hover{
  background: #4ab3c6;
}


.link{
  position: absolute;
  background: #e1eaeb;
  color: #7f7c7c;
  left: 0px;
  height: 20px;
  width: 440px;
  padding: 17px 30px 20px 30px;
  font-size: 16px;
  text-align: right;
  border-top: 1px solid #dbe5e8;
 
  -webkit-border-radius: 0 0  5px 5px;
  border-radius: 0 0  5px 5px;
}
 
.link a {
  font-weight: bold;
  background: #f7f8f1;
  padding: 6px;
  color: rgb(29, 162, 193);
  margin-left: 10px;
  border: 1px solid #cbd518;
 
  -webkit-border-radius: 4px;
  border-radius: 4px;  
 
  -webkit-transition: all 0.4s linear;
  transition: all 0.4s  linear;
}
 
.link a:hover {
  color: #39bfd7;
  background: #f7f7f7;
  border: 1px solid #4ab3c6;
}


#cadastro, 
#login{
  position: absolute;
  top: 0px;
  width: 88%;   
  padding: 18px 6% 60px 6%;
  margin: 0 0 35px 0;
  background: #f7f7f7;
  border: 1px solid rgba(147, 184, 189,0.8);
   
  -webkit-box-shadow: 5px;
  border-radius: 5px;
   
  -webkit-animation-duration: 0.5s;
  -webkit-animation-timing-function: ease;
  -webkit-animation-fill-mode: both;
 
  animation-duration: 0.5s;
  animation-timing-function: ease;
  animation-fill-mode: both;
}


/* Efeito ao clicar no botão ( Ir para Login ) */
#paracadastro:target ~ .content #cadastro,
#paralogin:target ~ .content #login{
  z-index: 2;
  -webkit-animation-name: fadeInLeft;
  animation-name: fadeInLeft;
 
  -webkit-animation-delay: .1s;
  animation-delay: .1s;
}
 
/* Efeito ao clicar no botão ( Cadastre-se ) */
#registro:target ~ .content #login,
#paralogin:target ~ .content #cadastro{
  -webkit-animation-name: fadeOutLeft;
  animation-name: fadeOutLeft;
}


/*fadeInLeft*/
@-webkit-keyframes fadeInLeft {
  0% {
    opacity: 0;
    -webkit-transform: translateX(-20px);
  }
  100% {
    opacity: 1;
    -webkit-transform: translateX(0);
  }
}
 
@keyframes fadeInLeft {
  0% {
    opacity: 0;
    transform: translateX(-20px);
  }
  100% {
    opacity: 1;
    transform: translateX(0);
  }
}
 
/*fadeOutLeft*/
@-webkit-keyframes fadeOutLeft {
  0% {
    opacity: 1;
    -webkit-transform: translateX(0);
  }
  100% {
    opacity: 0;
    -webkit-transform: translateX(-20px);
  }
}
 
@keyframes fadeOutLeft {
  0% {
    opacity: 1;
    transform: translateX(0);
  }
  100% {
    opacity: 0;
    transform: translateX(-20px);
  }
}
</style>
</html>