<html>
<?php
$V1 = 7.33; // Este valor corresponde a 7hs e 20min de trabalho diário
$ValorHora = $_POST["ValorHora"];
$Mes = $_POST["Mes"];
$DiasUteis = $_POST["DiasUteis"];
$Domingos = $_POST["Domingos"];
$DiasTrab = $_POST["DiasTrab"];
//$Tipo = $_POST["Tipo"];

//// CÁLCULO HORISTA /////

$HorasTrab = $DiasTrab * $V1;
$VlrHr = $HorasTrab * $ValorHora;
$DSR = $Domingos * $V1;
$VlrDSR = $DSR * $ValorHora;

     $HorasTrab = $DiasTrab * $V1;
             $VlrHr = $HorasTrab * $ValorHora;
             $DSR = $Domingos * $V1;
             $VlrDSR = $DSR * $ValorHora;
             $SalarioH = $VlrDSR + $VlrHr;
             echo "<center><font size=10; color = red><b>Resultado do cálculo demonstrativo de pagamento</center></b></font> <br>";

                   echo "<font size=6><center>O CALCULO COM BASE EM HORISTA FICA ASSIM<BR></font> </center>";
                   echo "<font size=5><center>Mês selecionado para o cálculo = $Mes</font> <br></center>";
                   echo "<font size=5><center>Cálculo das horas trabalhadas = $HorasTrab<br></font> </center>";
                   echo "<font size=5><center>Valor Hora = $VlrHr<br></font> </center>";
                   echo "<font size=5><center>Descanso Semanal Remunerado = $DSR<br></font> </center>";
                   echo "<font size=5><center>Valor do DSR = $VlrDSR<br></font> </center>";
             echo "<center><font size=5>Valor do Salário = $SalarioH <br></font> <p></center>";

//// FIM DO CÁLCULO DO SALÁRIO HORISTA /////



//// CÁLCULO MENSALISTA /////

       $Salario = 220 * $ValorHora;
       echo "<font size=6><center>O CALCULO COM BASE EM MENSALISTA FICA ASSIM<br></center></font>";
       echo "<center><font size=5>Cálculo das horas trabalhadas = $Salario<br></font></center>";

//// FIM DO CÁLCULO DO SALÁRIO MENSALISTA /////



?>    


</html>